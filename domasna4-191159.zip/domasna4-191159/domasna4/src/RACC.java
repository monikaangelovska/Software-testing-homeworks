import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

//test 1, 2, 4, 5

public class RACC {

    VacationPlans vacationPlans;

    @BeforeEach
    public void setUp() {
        vacationPlans = new VacationPlans();
    }

    //TTT
    @Test
    public void test1()
    {
        Person person = new Person("Monika", "Angelovska", 3000, 40000, 1);
        VacationDates dates = new VacationDates(true);
        String result = vacationPlans.canGoOnVacation(person, dates);
        assertEquals("The person " + person.name + " " + person.surname + " can go on a vacation.", result);
    }

    //TTF
    @Test
    public void test2()
    {
        Person person = new Person("Monika", "Angelovska", 4000, 500, 0);
        VacationDates dates = new VacationDates(true);
        String result = vacationPlans.canGoOnVacation(person, dates);
        assertEquals("The person " + person.name + " " + person.surname + " can not go on a vacation.", result);
    }

    //TFF
    @Test
    public void test4()
    {
        Person person = new Person("Monika", "Angelovska", 5000, 30000, 0);
        VacationDates dates = new VacationDates(false);
        String result = vacationPlans.canGoOnVacation(person, dates);
        assertEquals("The person " + person.name + " " + person.surname + " can go on a vacation.", result);
    }

    //FTT
    @Test
    public void test5()
    {
        Person person = new Person("Monika", "Angelovska", 4000, 2500, 1);
        VacationDates dates = new VacationDates(true);
        String result = vacationPlans.canGoOnVacation(person, dates);
        assertEquals("The person " + person.name + " " + person.surname + " can not go on a vacation.", result);
    }

}
