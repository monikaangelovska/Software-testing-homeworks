public class VacationPlans {
    public String canGoOnVacation(Person person, VacationDates vacationDates) {

        System.out.println("This program checks if a person can go on a vacation during a particular time.");

        boolean canGo = ((person.moneySaved > person.moneyNeeded) &&
                (!vacationDates.datesAreWorkingDays || (person.canUseVacationDays == 1)));

        if (canGo) {
            return "The person " + person.name + " " + person.surname + " can go on a vacation.";
        } else {
            return "The person " + person.name + " " + person.surname + " can not go on a vacation.";
        }
    }
}
