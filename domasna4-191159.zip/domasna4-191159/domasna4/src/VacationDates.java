public class VacationDates {
    public boolean datesAreWorkingDays;
    public VacationDates(boolean datesAreWorkingDays) {
        this.datesAreWorkingDays = datesAreWorkingDays;
    }
}