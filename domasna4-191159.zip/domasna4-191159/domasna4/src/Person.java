public class Person {
    public String name;
    public String surname;
    public int moneyNeeded;
    public int moneySaved;
    public int canUseVacationDays;

    public Person(String name, String surname, int moneyNeeded, int moneySaved, int canUseVacationDays) {
        this.name = name;
        this.surname = surname;
        this.moneyNeeded = moneyNeeded;
        this.moneySaved = moneySaved;
        this.canUseVacationDays = canUseVacationDays;
    }
}