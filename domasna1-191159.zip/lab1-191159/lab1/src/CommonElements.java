import java.util.ArrayList;
import java.util.List;

public class CommonElements {

    public static void main(String[] args) {
        List<String> list1 = new ArrayList<>();
        List<String> list2 = new ArrayList<>();

        list1.add("apple");
        list1.add("orange");
        list1.add("lime");

        list2.add("carrot");
        list2.add("orange");
        list2.add("apple");
    }

    public static List<String> commonElements(List<String> list1, List<String> list2) {

        if (list1 == null || list2 == null) {
            throw new NullPointerException();
        }

        list2.retainAll(list1);

        if (list2.isEmpty()) {
            return null;
        }
        else {
            return list2;
        }

    }

}
