import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class CommonElementsTest {

    @Test
    public void baseChoice() {
        List<String> list1 = new ArrayList<>();
        List<String> list2 = new ArrayList<>();

        list1.add("two");
        list1.add("apple");

        list2.add("apple");
        list2.add("one");

        List<String> list3 = new ArrayList<>();

        list3.add("apple");

        assertEquals(list3, CommonElements.commonElements(list1, list2));
    }

    @Test
    public void throwNullPointerException() {
        List<String> list2 = null;
        List<String> list1 = null;

        assertThrows(NullPointerException.class, ()->CommonElements.commonElements(list1, list2));
    }

    //lists not null and not empty -> FFFF
    @Test
    public void nullAndEmpty() {
        List<String> list1 = new ArrayList<>();
        list1.add("one");
        List<String> list2 = new ArrayList<>();
        list2.add("one");

        assertNotNull(CommonElements.commonElements(list1, list2));;
    }

    //lists empty but not null -> FFTF, FFFT
    @Test
    public void emptyNotNull() {
        List<String> list1 = new ArrayList<>();

        List<String> list2 = new ArrayList<>();
        list2.add("one");

        assertNull(CommonElements.commonElements(list1, list2));
    }

    @Test
    public void ifCommonElements() {
        List<String> list1 = new ArrayList<>();
        List<String> list2 = new ArrayList<>();

        list1.add("one");
        list1.add("two");
        list1.add("apple");

        list2.add("apple");
        list2.add("three");
        list2.add("one");

        List<String> list3 = new ArrayList<>();

        list3.add("apple");
        list3.add("one");

        assertEquals(list3, CommonElements.commonElements(list1, list2));
    }

}
