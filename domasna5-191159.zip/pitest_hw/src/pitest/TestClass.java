package pitest;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.testng.AssertJUnit.assertTrue;

public class TestClass {

    @Test
    public void testPersonToString()
    {
        Person attendee = new Person("Monika", "Angelovska", Role.OTHER, 20);
        attendee.setSurname("Angelovska");
        attendee.setAge(21);
        attendee.setRole(Role.STUDENT);
        attendee.toString();
        assertEquals("pitest.Person{name='Monika', surname='Angelovska', role=STUDENT, age=21}", attendee.toString());
    }

    @Test
    public void testCalculateTotalPricePaidAffiliate()
    {
        Conference conference = new Conference(20);
        Person attendee = new Person("Ana", "Angelovska", Role.AFFILIATE, 22);
        boolean added = conference.addAttendeeToConference(attendee);
        assertTrue(added);
        assertEquals(7.803, conference.calculateTotalPricePaid(), 0);
    }

    @Test
    public void testCalculateTotalPricePaidFacultyEmployee()
    {
        Conference conference = new Conference(100);
        Person attendee = new Person("Mario", "Angelovski", Role.FACULTY_EMPLOYEE, 30);
        boolean added = conference.addAttendeeToConference(attendee);
        assertTrue(added);
        assertEquals(2.6010000000000004, conference.calculateTotalPricePaid(), 0);
    }

    @Test
    public void testCalculateTotalPricePaidOther()
    {
        Conference conference = new Conference(500);
        Person attendee = new Person("Ivana", "Ivanova", Role.OTHER, 25);
        boolean added = conference.addAttendeeToConference(attendee);
        assertTrue(added);
        assertEquals(8.67, conference.calculateTotalPricePaid(), 0);
    }

    @Test
    public void testAddAttendeeToConferenceFalse() {
        Conference conference = new Conference(10000);
        for(int i=0; i<10000; i++) {
            Person attendee = new Person("Marko", "Trajkovski", Role.ORGANIZER, 32);
            boolean flagTrue = conference.addAttendeeToConference(attendee);
            assertEquals(true, flagTrue);
        }
        Person attendee2 = new Person("Sanja", "Angelova", Role.ORGANIZER, 32);
        boolean flagFalse = conference.addAttendeeToConference(attendee2);
        assertEquals(false, flagFalse);
    }

    @Test
    public void testDoubleCapacityFalse()
    {
        Conference conference = new Conference(10000);
        assertEquals(false, conference.doubleCapacity());
    }

    @Test
    public void testDoubleCapacityTrue()
    {
        Conference conference = new Conference(5000);
        assertTrue("true", conference.doubleCapacity());
    }

    @Test
    public void testDoubleCapacityMultiplication()
    {
        Conference conference = new Conference(100);
        conference.doubleCapacity();
        assertEquals(200, conference.getCapacity());
    }

    @Test
    public void testGetAttendees()
    {
        Conference conference = new Conference(300);
        Person organizer = new Person("Jana", "Jankova", Role.ORGANIZER, 40);
        Person other_participant = new Person("Ana", "Velkova", Role.OTHER, 25);
        conference.addAttendeeToConference(organizer);
        conference.addAttendeeToConference(other_participant);
        List<Person> attendees = conference.getAttendees();
        assertEquals(2, attendees.size());
    }

}
