package pitest;

public enum Role {
    FACULTY_EMPLOYEE,
    ORGANIZER,
    AFFILIATE,
    STUDENT,
    OTHER
}
